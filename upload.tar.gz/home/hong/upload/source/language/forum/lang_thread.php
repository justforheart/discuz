<?php

/**
 *      [Discuz!] (C)2001-2099 Comsenz Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: lang_thread.php 33048 2013-04-12 08:50:27Z zhangjie $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$lang = array (
	  'forum_archive' => '存档',
	  'source' => '来源',

	  't_question' => '？',
	  't_comma' => '，',
	  't_exclamatory' => '！',
	  't_period' => '。',
	  't_suspension' => '…',

);
?>