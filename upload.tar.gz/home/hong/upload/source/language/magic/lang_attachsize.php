<?php

/**
 *      [Discuz!] (C)2001-2099 Comsenz Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: lang_attachsize.php 27449 2012-02-01 05:32:35Z zhangguosheng $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$lang = array
(
	'attachsize_name' => '附件增容卡',
	'attachsize_desc' => '增加附件容量上限',
	'attachsize_info' => '额外增加 {num} M 附件容量上限',
	'attachsize_addsize' => '增加容量',
);

?>