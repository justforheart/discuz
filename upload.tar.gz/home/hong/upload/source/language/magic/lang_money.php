<?php

/**
 *      [Discuz!] (C)2001-2099 Comsenz Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: lang_money.php 27449 2012-02-01 05:32:35Z zhangguosheng $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$lang = array
(
	'money_name' => '金钱卡',
	'money_desc' => '可以随机获得特定积分',
	'money_info' => '获得的钱币数目规则：大于1且小于购买价格150%的随机数',
);

?>