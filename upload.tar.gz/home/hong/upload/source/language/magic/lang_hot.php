<?php

/**
 *      [Discuz!] (C)2001-2099 Comsenz Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: lang_hot.php 27449 2012-02-01 05:32:35Z zhangguosheng $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$lang = array
(
	'hot_name' => '热点灯',
	'hot_desc' => '把自己的日志热度增加站点推荐的热点值',
	'hot_info' => '把自己的日志热度增加 {num} 个热点值',
);

?>