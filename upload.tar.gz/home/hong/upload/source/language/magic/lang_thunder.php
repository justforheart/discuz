<?php

/**
 *      [Discuz!] (C)2001-2099 Comsenz Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: lang_thunder.php 27449 2012-02-01 05:32:35Z zhangguosheng $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$lang = array
(
	'thunder_name' => '雷鸣之声',
	'thunder_desc' => '发布一条全站动态，通知大家自己上线了',
	'thunder_info' => '发布一条全站动态，通知大家自己上线了',
);

?>