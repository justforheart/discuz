<?php

/**
 *      [Discuz!] (C)2001-2099 Comsenz Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: lang_template.php 28113 2012-02-22 09:25:55Z svn_project_zhangjie $
 *
 *      This file is automatically generate
 */

$lang = array (
  'no_tag' => '还没有任何标签',
  'tag' => '标签',
  'blog_read' => '次阅读',
  'blog_replay' => '个评论',
  'empty_tags' => '没有此标签，您可以继续搜索或者<a href="misc.php?mod=tag" title="返回标签首页">返回标签首页</a>',
  'forum' => '版块',
  'hot' => '热度',
  'lastpost' => '最后发表',
  'no_content' => '没有相关内容',
  'personal_category' => '个人分类',
  'related_blog' => '相关日志',
  'related_thread' => '相关帖子',
  'replies' => '回复/查看',
  'price' => '售价',
);

?>