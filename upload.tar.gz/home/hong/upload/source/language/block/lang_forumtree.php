<?php

/**
 *      [Discuz!] (C)2001-2099 Comsenz Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: lang_forumtree.php 27449 2012-02-01 05:32:35Z zhangguosheng $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$lang = array
(
	'forumtree_name' => '版块树形列表',
	'forumtree_desc' => '树形显示版块列表',
	'forumtree_fids' => '显示的版块',
	'forumtree_fids_comment' => '设置允许显示的版块，留空为显示所有版块',
);

?>