<?php

/**
 *      [Discuz!] (C)2001-2099 Comsenz Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: lang_announcement.php 27449 2012-02-01 05:32:35Z zhangguosheng $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$lang = array
(
	'announcement_type' => '公告类型',
	'announcement_type_text' => '文字公告',
	'announcement_type_link' => '网站链接',
	'announcement_titlelength' => '标题长度',
	'announcement_summarylength' => '内容长度',
	'announcement_startrow' => '起始位置',
);
?>