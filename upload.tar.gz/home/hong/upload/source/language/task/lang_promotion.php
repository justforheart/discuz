<?php

/**
 *      [Discuz!] (C)2001-2099 Comsenz Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: lang_promotion.php 27449 2012-02-01 05:32:35Z zhangguosheng $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$lang = array
(
	'promotion_name' => '站点推广任务',
	'promotion_desc' => '到“<a href="home.php?mod=spacecp&ac=promotion" target="_blank" class="xi2">访问推广</a>”页面，复制您的推广链接，发给QQ好友、您的博客或其他大型网站，推广获积分',
	'promotion_complete_var_iplimit' => '推广 IP 数下限',
	'promotion_complete_var_iplimit_comment' => '当日推广 IP 数大于或等于此设置，才能完成任务',
);

?>