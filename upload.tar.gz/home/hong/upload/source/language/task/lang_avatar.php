<?php

/**
 *      [Discuz!] (C)2001-2099 Comsenz Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: lang_avatar.php 27449 2012-02-01 05:32:35Z zhangguosheng $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$lang = array
(
	'avatar_name' => '头像类任务',
	'avatar_desc' => '该任务仅限没有上传头像的会员申请，申请后只要上传头像即可完成任务，获得相应的奖励',
	'avatar_view' => '<strong>请按照以下的说明来参与本任务：</strong>
		<ul>
		<li>1. <a href="home.php?mod=spacecp&ac=avatar" target="_blank">新窗口打开上传头像页面</a></li>
		<li>2. 上传一个自己的头像照片</li>
		</ul>',
);

?>