<?php

/**
 *      [Discuz!] (C)2001-2099 Comsenz Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: lang_blog.php 27449 2012-02-01 05:32:35Z zhangguosheng $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$lang = array
(
	'blog_name' => '发表日志任务',
	'blog_desc' => '发表日志即可完成任务，获得相应的奖励',
	'blog_view' => '<strong>请按照以下的说明来参与本任务：</strong>
		<ul>
		<li>1. <a href="home.php?mod=spacecp&ac=blog" target="_blank">新窗口打开发表日志页面</a></li>
		<li>2. 在新打开的页面中，书写自己的第一篇日志，并进行发布</li>
		</ul>',
);

?>